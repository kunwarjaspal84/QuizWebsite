var CorrectAnswercount = 0;
var a = Math.floor(Math.random() * 10);
var questions = 0;
generate(a);
var dbName = localStorage.getItem('name');
var name = dbName.valueOf();

window.alert("Please do not refresh the page or the quiz will restart");
function generate(index) {



	document.getElementById("question").innerHTML = jsondata[index].question ;
	
	document.getElementById("optt1").innerHTML = jsondata[index].opt1 ;

	document.getElementById("optt2").innerHTML = jsondata[index].opt2 ;

	document.getElementById("optt3").innerHTML = jsondata[index].opt3 ;

	document.getElementById("optt4").innerHTML = jsondata[index].opt4 ;


}
function random(index)
{
	questions++;

	index = index + 7;
	if(index>20)
	{
		index = index%10;
	}
	a = index;
}
function one(){
	document.getElementById("name1").innerHTML = localStorage.getItem("name").valueOf();
	}

function checkAnswers(){



		if(document.getElementById("opt1").checked && jsondata[a].opt1 === jsondata[a].answer){

			CorrectAnswercount++;
			
		}
		if(document.getElementById("opt2").checked && jsondata[a].opt2 === jsondata[a].answer){

			CorrectAnswercount++;
			
		}
		if(document.getElementById("opt3").checked && jsondata[a].opt3 === jsondata[a].answer){

			CorrectAnswercount++;
		
		}
		if(document.getElementById("opt4").checked && jsondata[a].opt4 === jsondata[a].answer){

			CorrectAnswercount++;
			
		}
		document.getElementById("opt1").checked = false;
		document.getElementById("opt2").checked = false;
		document.getElementById("opt3").checked = false;
		document.getElementById("opt4").checked = false;
		random(a);

		if(questions == 10){

			var audio = new Audio('music/bensound-buddy.mp3');
			audio.play();
			localStorage.setItem('score',CorrectAnswercount);
			window.location.href = "finalPage.html";

	
			//document.write(""+name +   " your score  is "  + CorrectAnswercount+"");
			

		}


		generate(a);


}
