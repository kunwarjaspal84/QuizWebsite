function set(){

	var input = document.getElementById("name");
	  if (!input.checkValidity()) {
	    alert(input.validationMessage);
	  }else{
	  	var name = document.getElementById('name').value;
	  	localStorage.setItem('name',name);

	  	window.open("mainpage.html");
	  }
	
	

}